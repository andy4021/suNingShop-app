<template>
    <section>
        <div class="backcolor">

        </div>
        <div class="usermsg">
            <div class="user_top">
                <div class="top_left">
                    <img src="/static/my/use01.jpg" alt=""/>
                    <p>
                        <span>18792995525</span>
                        <img src="/static/my/use03.jpg" alt=""/>
                    </p>
                </div>
                <img class="top_img" src="/static/my/use02.jpg" alt=""/>
            </div>
            <div class="user_midd">
                <p>
                    <span>0</span>
                    <span>优惠券</span>
                </p>
                <p>
                    <span>2</span>
                    <span>云钻</span>
                </p>
                <p>
                    <span>￥0.00</span>
                    <span>小店卡</span>
                </p>
            </div>
            <div class="user_bott">
                <span>SUPER会员小店板，预计每年可省720元</span>
                <span>去开通</span>
            </div>
        </div>
        <div class="myorder">
            <p class="order">我的订单</p>
            <div class="order_bott">
                <img src="/static/my/d01.jpg" alt=""/>
                <p>新鲜生活，从小店第一单开始</p>
                <img src="/static/my/d02.jpg" alt=""/>
            </div>
        </div>
        <img class="adv" src="/static/my/d03.jpg" alt=""/>
        <div class="myorder server">
            <div class="title">
                <h3 class="tit">服务中心</h3>
            </div>
            <div class="content">
                <a href="#"><img src="/static/my/d04.jpg" alt=""/><span>帮助中心</span></a>
                <a href="#"><img src="/static/my/d04.jpg" alt=""/><span>意见反馈</span></a>
                <a href="#"><img src="/static/my/d04.jpg" alt=""/><span>退款记录</span></a>
                <a href="#"><img src="/static/my/d04.jpg" alt=""/><span>发票中心</span></a>
            </div>
        </div>
        <div class="myorder server">
            <div class="title">
                <h3 class="tit">我的邮局</h3>
                <a href="#">去邮局首页<img src="/static/my/Post03.jpg" alt=""/></a>
            </div>
            <div class="content_a">
                <a class="post_a" href="#">
                    <img src="/static/my/Post01.jpg" alt=""/>
                    <p><span>安全地址</span><span>安全收货隐私保护</span></p>
                </a>
                <a class="post_a" href="#">
                    <img src="/static/my/Post02.jpg" alt=""/>
                    <p><span>安全地址</span><span>帮助中心</span></p>
                </a>
            </div>
        </div>
        <div class="myorder server">
            <div class="title">
                <h3 class="tit">小店SUPER会员专享</h3>
                <a href="#">更多<img src="/static/my/Post03.jpg" alt=""/></a>
            </div>
            <div class="vip_goods">
                <a href="#">
                    <img class="discount" src="/static/my/vip01.jpg" alt=""/>
                    <img src="/static/my/vip02.jpg" alt=""/>
                    <p>贝拉小蜜蜂BELLABEE婴儿植物洗衣液3000ml...</p>
                    <span>￥23.9</span>
                    <p>￥19.9 <img src="/static/my/vip04.jpg" alt=""/></p>
                    <img class="cart" src="/static/my/vip05.jpg" alt=""/>
                </a>
                <a href="#">
                    <img class="discount" src="/static/my/vip01.jpg" alt=""/>
                    <img src="/static/my/vip02.jpg" alt=""/>
                    <p>贝拉小蜜蜂BELLABEE婴儿植物洗衣液3000ml...</p>
                    <span>￥23.9</span>
                    <p>￥19.9 <img src="/static/my/vip04.jpg" alt=""/></p>
                    <img class="cart" src="/static/my/vip05.jpg" alt=""/>
                </a>
                <a href="#">
                    <img class="discount" src="/static/my/vip01.jpg" alt=""/>
                    <img src="/static/my/vip02.jpg" alt=""/>
                    <p>贝拉小蜜蜂BELLABEE婴儿植物洗衣液3000ml...</p>
                    <span>￥23.9</span>
                    <p>￥19.9 <img src="/static/my/vip04.jpg" alt=""/></p>
                    <img class="cart" src="/static/my/vip05.jpg" alt=""/>
                </a>
                <a href="#">
                    <img class="discount" src="/static/my/vip01.jpg" alt=""/>
                    <img src="/static/my/vip02.jpg" alt=""/>
                    <p>贝拉小蜜蜂BELLABEE婴儿植物洗衣液3000ml...</p>
                    <span>￥23.9</span>
                    <p>￥19.9 <img src="/static/my/vip04.jpg" alt=""/></p>
                    <img class="cart" src="/static/my/vip05.jpg" alt=""/>
                </a>
                <a href="#">
                    <img class="discount" src="/static/my/vip01.jpg" alt=""/>
                    <img src="/static/my/vip02.jpg" alt=""/>
                    <p>贝拉小蜜蜂BELLABEE婴儿植物洗衣液3000ml...</p>
                    <span>￥23.9</span>
                    <p>￥19.9 <img src="/static/my/vip04.jpg" alt=""/></p>
                    <img class="cart" src="/static/my/vip05.jpg" alt=""/>
                </a>
                <a href="#">
                    <img class="discount" src="/static/my/vip01.jpg" alt=""/>
                    <img src="/static/my/vip02.jpg" alt=""/>
                    <p>贝拉小蜜蜂BELLABEE婴儿植物洗衣液3000ml...</p>
                    <span>￥23.9</span>
                    <p>￥19.9 <img src="/static/my/vip04.jpg" alt=""/></p>
                    <img class="cart" src="/static/my/vip05.jpg" alt=""/>
                </a>
                <a href="#">
                    <img class="discount" src="/static/my/vip01.jpg" alt=""/>
                    <img src="/static/my/vip02.jpg" alt=""/>
                    <p>贝拉小蜜蜂BELLABEE婴儿植物洗衣液3000ml...</p>
                    <span>￥23.9</span>
                    <p>￥19.9 <img src="/static/my/vip04.jpg" alt=""/></p>
                    <img class="cart" src="/static/my/vip05.jpg" alt=""/>
                </a>
            </div>
        </div>
    </section>
</template>

<script>
    export default {
        name: "mySection"
    }
</script>

<style scoped>
    section{
        -webkit-flex:1;
        overflow-y: auto;
        overflow-x: hidden;
        position: relative;
        background:#f2f2f2;
    }
    .backcolor{
        width:100%;
        height:1.22rem;
        background:url("/static/my/head04.jpg") repeat-y;
        background-size:100%;
    }
    .usermsg{
        background:url("/static/my/use04.jpg") repeat-y;
        background-size:100%;
        width:3.55rem;
        margin:0 auto;
        border-radius:.1rem;
        box-shadow:0 2px 3px #cbcbcb;
        position:absolute;
        left:.1rem;
        top:0;
    }
    .user_top{
        display:-webkit-flex;
        -webkit-justify-content:space-between;
        -webkit-align-items:center;
        height:1.1rem;
    }
    .top_left{
        display:-webkit-flex;
    }
    .top_left img:first-child{
        width:.72rem;
        height:.72rem;
        margin:0 .1rem 0 .12rem;
    }
    .top_left p span{
        font-size:12px;
        color:#2e2e2e;
        display:block;
        margin-top:.17rem;
    }
    .top_left p img{
        width:.59rem;
        height:.16rem;
        margin-top:.05rem;
    }
    .top_img{
        width:.3rem;
        height:.42rem;
        margin-right:.12rem;
    }
    .user_midd{
        display:-webkit-flex;

    }
    .user_midd p{
        width:33%;
    }
    .user_midd p span{
        display:block;
        text-align:center;
    }
    .user_midd p span:first-child{
        font-size:13px;
        color:#f29f37;
    }
    .user_midd p span:last-child{
        font-size:13px;
        color:#7a7a7a;
    }
    .user_bott{
        display:-webkit-flex;
        -webkit-justify-content: space-between;
        padding:.3rem .12rem .08rem;
    }
    .user_bott span:first-child{
        font-size:11px;
        color:#222222;
    }
    .user_bott span:last-child{
        font-size:11px;
        color:#ef8e34;
        width:.6rem;
        height:.24rem;
        border:1px solid #ef8e34;
        border-radius:.04rem;
        text-align:center;
        line-height:.24rem;
    }
    .myorder{
        border-radius:.1rem;
        background:white;
        width:3.55rem;
        margin:1.06rem auto 0;
    }
    .order{
        height:.4rem;
        font-size:15px;
        color:#2e2e2e;
        font-weight:900;
        line-height: .4rem;
        padding-left:.12rem;
        border-bottom:1px solid #ebebeb;
    }
    .order_bott{
        padding-bottom:.1rem;
    }
    .order_bott img:first-child{
        width:.4rem;
        height:.4rem;
        margin:.12rem auto .05rem;
    }
    .order_bott p{
        font-size:11px;
        color:#333333;
        text-align:center;
    }
    .order_bott img:last-child{
        width:.7rem;
        height:.24rem;
        margin:.07rem auto 0;
    }
    .adv{
        width:3.55rem;
        margin:.1rem auto 0;
    }
    .server{
        margin-top:.1rem;
    }
    .title{
        border-bottom:1px solid #ebebeb;
        height:.4rem;
        margin-left:.12rem;
    }
    .tit{
        font-size:15px;
        color:#222222;
        line-height:.4rem;
    }
    .content{
        display:-webkit-flex;
        padding-bottom:.2rem;
    }
    .content a{
        width:25%;
        text-align:center;
    }
    .content a img{
        width:.22rem;
        height:.22rem;
        margin:.2rem auto 0;
    }
    .content a span{
        font-size:13px;
        color:#323232;
        display:block;
        margin-bottom:.02rem;
    }
    .title{
        display:-webkit-flex;
        justify-content:space-between;
        -webkit-align-items:center;

    }
    .title a{
        font-size:12px;
        color:#999999;
        display:-webkit-flex;
        -webkit-align-items:center;
    }
    .title a img{
        width:.07rem;
        height:.1rem;
        margin:0 .12rem 0 .06rem;
    }
    .content_a{
        display:-webkit-flex;
        height:.69rem;
        -webkit-align-items:center;
        padding-bottom:.06rem;
    }
    .post_a{
        display:-webkit-flex;
        width:50%;
    }
    .post_a img{
        width:.33rem;
        height:.39rem;
        margin-left:.21rem;
    }
    .post_a p{
        margin-left:.1rem;
    }
    .post_a p span{
        font-size:14px;
        color:#9d9d9d;
        display:block;
    }
    .post_a p span:first-child{
        color:#222222;
    }
    .vip_goods{
        display:-webkit-flex;
        position:relative;
        flex-wrap:wrap;
    }
    .vip_goods a{
        width:50%;
        position:relative;
        padding-bottom:.15rem;
        border-right:1px solid #f2f2f2;
        border-bottom:1px solid #f2f2f2;
        box-sizing:border-box;
    }
    .vip_goods a:nth-child(2n){
        border-right:0;
    }
    .vip_goods a img:nth-child(2){
        width:.93rem;
        height:1.37rem;
        margin:.21rem auto .15rem;
    }
    .vip_goods a p:nth-child(3){
        font-size:13px;
        color:black;
        width:1.5rem;
        text-align:center;
    }
    .vip_goods span:nth-child(4){
        font-size:10px;
        color:#f07d32;
        display:block;
        margin:.06rem 0 .08rem;
    }
    .vip_goods a p:nth-child(5){
        font-size:12px;
        color:#ecba3e;
        font-weight:900;
        display:-webkit-flex;
        -webkit-align-items:center;
    }
    .vip_goods a p:nth-child(5) img{
        width:.4rem;
        height:.1rem;
        margin-left:.04rem;
    }
    .discount{
        width:.34rem;
        height:.24rem;
        position:absolute;
        left:.1rem;
        top:.08rem;
    }
    .cart{
        width:.29rem;
        height:.29rem;
        position:absolute;
        bottom:.1rem;
        right:.1rem;
    }
</style>
