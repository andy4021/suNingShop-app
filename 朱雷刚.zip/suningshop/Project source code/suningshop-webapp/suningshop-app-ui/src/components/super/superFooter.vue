<template>
    <footer>
        <img src="/static/super/adv08.jpg" alt="">
    </footer>
</template>

<script>
    export default {
        name: "superFooter"
    }
</script>

<style scoped>
    footer{
        width: 100%;
        height: .5rem;
        border-top: 1px solid #f1f1f1;
        position: relative;
    }
    footer img{
        width:3.65rem;
        height: .56rem;
        position:absolute;
        left:.05rem;
        top:-.12rem;
    }
</style>