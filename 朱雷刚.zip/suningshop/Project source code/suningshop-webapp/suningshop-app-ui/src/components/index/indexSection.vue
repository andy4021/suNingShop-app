<template>
  <!-- section -->
  <section>
    <div class="nav">
      <a href="#"><img src="/static/img-id/n01.png" alt=""/><span>充值有礼</span></a>
      <a href="/#/supera"><img src="/static/img-id/n02.png" alt=""/><span>SPUER会员</span></a>
      <a href="#"><img src="/static/img-id/n03.png" alt=""/><span>充值有礼</span></a>
      <a href="#"><img src="/static/img-id/n04.png" alt=""/><span>充值有礼</span></a>
    </div>
    <!-- banner -->
    <div class="banner">
      <!-- <img src="img/banner.png" width="100%"/> -->
      <div class="swiper-container">
        <div class="swiper-wrapper">
          <div class="swiper-slide"><img src="/static/img-id/adv1.png" alt=""/></div>
          <div class="swiper-slide">Slide 2</div>
          <div class="swiper-slide">Slide 3</div>
        </div>
        <!-- 如果需要分页器 -->
        <div class="swiper-pagination"></div>

        <!-- 如果需要导航按钮 -->
        <!-- <div class="swiper-button-prev"></div> -->
        <!-- <div class="swiper-button-next"></div> -->

        <!-- 如果需要滚动条 -->
        <!-- <div class="swiper-scrollbar"></div> -->
      </div>
    </div>
    <div class="menu">
      <a href="/#/vegetables"><img src="/static/img-id/classification01.png" alt=""/><span>生鲜果蔬</span></a>
      <a href="#"><img src="/static/img-id/classification01.png" alt=""/><span>酒水饮料</span></a>
      <a href="/#/selection"><img src="/static/img-id/classification01.png" alt=""/><span>苏宁精选</span></a>
      <a href="#"><img src="/static/img-id/classification01.png" alt=""/><span>烘焙乳品</span></a>
      <a href="#"><img src="/static/img-id/classification01.png" alt=""/><span>生活用品</span></a>
      <a href="#"><img src="/static/img-id/classification01.png" alt=""/><span>生鲜果蔬</span></a>
      <a href="#"><img src="/static/img-id/classification01.png" alt=""/><span>酒水饮料</span></a>
      <a href="#"><img src="/static/img-id/classification01.png" alt=""/><span>苏宁精选</span></a>
      <a href="#"><img src="/static/img-id/classification01.png" alt=""/><span>烘焙乳品</span></a>
      <a href="#"><img src="/static/img-id/classification01.png" alt=""/><span>生活用品</span></a>
    </div>
    <div class="back">
      <div class="adv">
        <img src="/static/img-id/adv2.png" alt=""/>
      </div>
      <!-- 会员爆款 -->
      <div class="explosion">
        <div class="exp_one">
          <div class="exp_left">
            <img src="/static/img-id/v01.png" alt=""/>
            <h3>会员爆款</h3>
            <img src="/static/img-id/v011.png" alt=""/>
            <span>会员专享 超值精选</span>
          </div>
          <div class="exp_right">
            <span>更多</span>
            <img src="/static/img-id/v012.png" alt=""/>
          </div>
        </div>
        <div class="exp_two">
          <div class="exp_detail">
            <img src="/static/img-id/v02.png" alt=""/>
            <p>贝拉小蜜蜂BALLABEE婴•••</p>
            <h4 class="price">￥23.9</h4>
            <h3 class="vip_price">￥19.9</h3>
            <img class="vip" src="/static/img-id/v06.png" alt=""/>
            <img class="goodscat" src="/static/img-id/v05.png" alt=""/>
          </div>
          <div class="exp_detail">
            <img src="/static/img-id/v03.png" alt=""/>
            <p>贝拉小蜜蜂BALLABEE婴•••</p>
            <h4 class="price">￥23.9</h4>
            <h3 class="vip_price">￥19.9</h3>
            <img class="vip" src="/static/img-id/v06.png" alt=""/>
            <img class="goodscat" src="/static/img-id/v05.png" alt=""/>
          </div>
          <div class="exp_detail">
            <img src="/static/img-id/v04.png" alt=""/>
            <p>贝拉小蜜蜂BALLABEE婴•••</p>
            <h4 class="price">￥23.9</h4>
            <h3 class="vip_price">￥19.9</h3>
            <img class="vip" src="/static/img-id/v06.png" alt=""/>
            <img class="goodscat" src="/static/img-id/v05.png" alt=""/>
          </div>
          <div class="exp_detail">
            <img src="/static/img-id/v02.png" alt=""/>
            <p>贝拉小蜜蜂BALLABEE婴•••</p>
            <h4 class="price">￥23.9</h4>
            <h3 class="vip_price">￥19.9</h3>
            <img class="vip" src="/static/img-id/v06.png" alt=""/>
            <img class="goodscat" src="/static/img-id/v05.png" alt=""/>
          </div>
        </div>
      </div>
      <img class="adv03" src="/static/img-id/adv3.png" alt=""/>
      <!-- 甄选乳品 -->
      <div class="dairy">
        <img src="/static/img-id/dairy01.png" alt=""/>
        <div class="dairy_detail">
          <a href="#">
            <img src="/static/img-id/dairy02.png" alt=""/>
            <p>伊利安慕希205ml</p>
            <span>￥5.5</span>
            <img src="/static/img-id/v05.png" alt=""/>
          </a>
          <a href="#">
            <img src="/static/img-id/dairy03.png" alt=""/>
            <p>伊利安慕希205ml</p>
            <span>￥5.5</span>
            <img src="/static/img-id/v05.png" alt=""/>
          </a>
          <a href="#">
            <img src="/static/img-id/dairy04.png" alt=""/>
            <p>伊利安慕希205ml</p>
            <span>￥5.5</span>
            <img src="/static/img-id/v05.png" alt=""/>
          </a>
          <a href="#">
            <img src="/static/img-id/dairy02.png" alt=""/>
            <p>伊利安慕希205ml</p>
            <span>￥5.5</span>
            <img src="/static/img-id/v05.png" alt=""/>
          </a>
        </div>
      </div>
      <!-- 零食派对 -->
      <div class="dairy snack">
        <img src="/static/img-id/snack01.png" alt=""/>
        <div class="dairy_detail">
          <a href="#">
            <img src="/static/img-id/snack02.png" alt=""/>
            <p>洽洽香花生（椒盐味） 88g</p>
            <h4 class="price">￥23.9</h4>
            <h3 class="vip_price">￥19.9</h3>
            <img class="vip" src="/static/img-id/v06.png" alt=""/>
            <img src="/static/img-id/v05.png" alt=""/>
          </a>
          <a href="#">
            <img src="/static/img-id/snack03.png" alt=""/>
            <p>伊利安慕希205ml</p>
            <h4 class="price">￥23.9</h4>
            <h3 class="vip_price">￥19.9</h3>
            <img class="vip" src="/static/img-id/v06.png" alt=""/>
            <img src="/static/img-id/v05.png" alt=""/>
          </a>
          <a href="#">
            <img src="/static/img-id/snack04.png" alt=""/>
            <p>伊利安慕希205ml</p>
            <h4 class="price">￥23.9</h4>
            <h3 class="vip_price">￥19.9</h3>
            <img class="vip" src="/static/img-id/v06.png" alt=""/>
            <img src="/static/img-id/v05.png" alt=""/>
          </a>
          <a href="#">
            <img src="/static/img-id/snack02.png" alt=""/>
            <p>伊利安慕希205ml</p>
            <h4 class="price">￥23.9</h4>
            <h3 class="vip_price">￥19.9</h3>
            <img class="vip" src="/static/img-id/v06.png" alt=""/>
            <img class="" src="/static/img-id/v05.png" alt=""/>
          </a>
        </div>
      </div>
      <!-- 苏宁精选 -->
      <div class="explosion">
        <div class="exp_one">
          <div class="exp_left">
            <img src="/static/img-id/selec01.png" alt=""/>
            <h3>苏宁精选</h3>
            <img src="/static/img-id/v011.png" alt=""/>
            <span>好货云集 大牌钜惠</span>
          </div>
        </div>
        <div class="selected">
          <div class="selec_left">
            <h3 class="selec_title">超市精选<img src="/static/img-id/selec02.png" alt=""/></h3>
            <p class="selec_word">粮油疯抢72小时</p>
            <img class="imgs" src="/static/img-id/selec03.png" alt=""/>
          </div>
          <div class="selec_center">
            <h3 class="selec_title">苏宁生鲜</h3>
            <p class="selec_word">满118减30</p>
            <img src="/static/img-id/selec04.png" alt=""/>
          </div>
          <div class="selec_right">
            <h3 class="selec_title">手机开学季</h3>
            <p class="selec_word">抢1000元卷</p>
            <img src="/static/img-id/selec05.png" alt=""/>
          </div>
        </div>
      </div>
      <!-- 猜你喜欢 -->
      <div class="explosion">
        <div class="exp_one">
          <div class="exp_left">
            <img src="/static/img-id/like03.png" alt=""/>
            <h3>猜你喜欢</h3>
            <img src="/static/img-id/v011.png" alt=""/>
            <span>热销商品 不容错过</span>
          </div>
        </div>
        <div class="you_like">
          <a class="like">
            <img src="/static/img-id/like01.png" alt=""/>
            <p>椰树椰汁椰子汁330ml（利乐）</p>
            <h4 class="price">￥23.9</h4>
            <img class="goodscat" src="/static/img-id/v05.png" alt=""/>
          </a>
          <a class="like">
            <img src="/static/img-id/like02.png" alt=""/>
            <p>红牛维生素更能饮料250ml</p>
            <h4 class="price">￥23.9</h4>
            <img class="goodscat" src="/static/img-id/v05.png" alt=""/>
          </a>
          <a class="like">
            <img src="/static/img-id/like01.png" alt=""/>
            <p>椰树椰汁椰子汁330ml（利乐）</p>
            <h4 class="price">￥23.9</h4>
            <img class="goodscat" src="/static/img-id/v05.png" alt=""/>
          </a>
          <a class="like">
            <img src="/static/img-id/like02.png" alt=""/>
            <p>红牛维生素更能饮料250ml</p>
            <h4 class="price">￥23.9</h4>
            <img class="goodscat" src="/static/img-id/v05.png" alt=""/>
          </a>
          <a class="like">
            <img src="/static/img-id/like01.png" alt=""/>
            <p>椰树椰汁椰子汁330ml（利乐）</p>
            <h4 class="price">￥23.9</h4>
            <img class="goodscat" src="/static/img-id/v05.png" alt=""/>
          </a>
          <a class="like">
            <img src="/static/img-id/like02.png" alt=""/>
            <p>红牛维生素更能饮料250ml</p>
            <h4 class="price">￥23.9</h4>
            <img class="goodscat" src="/static/img-id/v05.png" alt=""/>
          </a>

        </div>
      </div>
    </div>
  </section>


</template>
<script>
    // import'../../node_modules/vue-swiper/dist/vue-swiper.js'
    import Swiper from "swiper"
    export default {
        name: "indexSection",
        mounted(){
             new Swiper ('.swiper-container', {
                direction: 'horizontal',
                loop: true,
                speed:1000,
                //   effect : 'fade',
                //   autoplay:true,

                autoplay: {
                    delay: 3000,
                    stopOnLastSlide: false,
                    disableOnInteraction: false,
                },
                // 如果需要分页器
                pagination: {
                    el: '.swiper-pagination',
                    clickable :true,
                },
                // 如果需要前进后退按钮
                navigation: {
                    nextEl: '.swiper-button-next',
                    prevEl: '.swiper-button-prev',
                },

                //   nextButton: '.swiper-button-next',
                //   prevButton: '.swiper-button-prev',

                // 如果需要滚动条
                scrollbar: '.swiper-scrollbar',
            })
        }
    }

</script>
<style scoped>
  @import'../../assets/css/swiper.min.css';

  .nav{
    display: -webkit-flex;
    width:100%;
    padding-top:.09rem;
    padding-bottom:.13rem;
  }
  .nav a{
    -webkit-flex:1;
    text-align:center;
  }
  .nav a img{
    width:.27rem;
    height:.27rem;
    margin:0 auto;
  }
  .nav a span{
    display:block;
    font-size:12px;
    color:#323232;
    line-height: 12px;
    margin-top:.07rem;
  }
  .menu{
    display: -webkit-flex;
    -webkit-flex-wrap:wrap;
  }
  .menu a{
    width:20%;
    text-align: center;
  }
  .menu img{
    width: .48rem;
    height: .48rem;
    margin:.12rem auto .07rem;
  }
  .menu span{
    color: #333333;
    font-size: 11px;
    display: block;
  }
  .back{
    width:100%;
    background:#f2f2f2;
    padding-bottom:.15rem;
  }
  .adv{
    width:100%;
  }
  .adv img{
    width:3.55rem;
    height:.99rem;
    margin:.2rem auto 0;
  }
  /* banner */
  .swiper-container{
    width:3.55rem;
    /* height:1.5rem; */
  }
  .swiper-slide img{
    width:3.55rem;
    /* height:1.4rem; */
  }
  .swiper-pagination-bullet{
    width:4px;
    height:4px;
  }
  .swiper-pagination-bullet-active{
    width:.1rem;
    height:4px;
    background:white;
    opacity:1;
  }
  /* 会员爆款 */
  .explosion{
    width:3.55rem;
    border-radius:.12rem;
    background: white;
    margin:.1rem auto .16rem;
    padding-bottom:.05rem;
  }
  .exp_one{
    display: -webkit-flex;
    -webkit-align-items:center;
    -webkit-justify-content:space-between;
    padding:.1rem .17rem .12rem .08rem;
    border-bottom:2px solid #f2f2f2;
  }
  .exp_left{
    display: -webkit-flex;
    -webkit-align-items:center;
  }
  .exp_left h3{
    font-size:15px;
    font-family:"黑体";
    color:#363636;
  }
  .exp_left img:nth-child(1){
    width:.2rem;
    height:.19rem;
    margin-right:.05rem;
  }
  .exp_left img:nth-child(3){
    width:.05rem;
    height:.05rem;
    margin:0 .05rem;
  }
  .exp_left span{
    font-size:.12rem;
    color:#a3a3a3;
  }
  .exp_right{
    display:-webkit-flex;
    -webkit-align-items:center;
  }
  .exp_right span{
    font-size:.12rem;
    color:#a3a3a3;
  }
  .exp_right img{
    width:.05rem;
    height:.09rem;
    margin-left:.06rem;
  }
  .exp_two{
    display:-webkit-flex;
    padding-left:.13rem;
    overflow-x:auto;
    padding-bottom:.06rem;
  }
  .exp_detail{
    position:relative;
    margin-right:.15rem;
    margin-top:.15rem;
  }
  .exp_detail img:nth-child(1){
    width:.55rem;
    height:.8rem;
    margin:0 auto;
  }
  .vip{
    width:.46rem;
    height:.12rem;
  }
  .exp_detail img:nth-child(6){
    width:.28rem;
    height:.27rem;
    position: absolute;
    right:0;
    bottom:.13rem;
  }
  .exp_detail p{
    font-size:12px;
    color:#424242;
    width:.92rem;
    line-height: .15rem;
    margin-top:.1rem;
  }
  .price{
    font-size:10px;
    color:#ec672e;
    font-family: "黑体";
    margin:.01rem 0;
  }
  .vip_price{
    font-size:12px;
    color:#e7ad3b;
    font-family: "黑体";
    margin-bottom:.01rem;
  }
  .adv03{
    width:3.55rem;
    height:.85rem;
    margin:0 auto;
  }
  .dairy{
    width:3.55rem;
    margin:.18rem auto 0;
    background:white;
    border-bottom-left-radius:.12rem;
    border-bottom-right-radius:.12rem;
    padding-bottom:.28rem;
  }
  .dairy img:nth-child(1){
    width:3.55rem;
    height:.8rem;
  }
  .dairy_detail{
    display:-webkit-flex;
    overflow-x:auto;
  }
  .dairy_detail a{
    position: relative;
    margin-top:.17rem;
    padding-left:.12rem;
    margin-right:.1rem;
  }
  .dairy_detail a img:nth-child(1){
    width:.59rem;
    height:.84rem;
    margin:0 auto .1rem;
  }
  .dairy_detail a img:nth-child(4){
    width:.28rem;
    height:.27rem;
    position: absolute;
    right:0;
    bottom:0;
  }
  .dairy_detail a p{
    font-size:12px;
    color:#5b5b5b;
    width:.9rem;
  }
  .dairy_detail a span{
    display: block;
    font-size:10px;
    color:#ec622a;
    font-family: "黑体";
    margin-top:.18rem;
  }
  .snack .dairy_detail img:nth-child(1){
    width:.85rem;
    height:.87rem;
  }
  .snack .dairy_detail a img:last-child{
    width:.28rem;
    height:.27rem;
    position: absolute;
    right:0;
    bottom:.13rem;

  }
  /* 苏宁精选 */
  .selected{
    display:-webkit-flex;
  }
  .selec_left,.selec_center{
    border-right:2px solid #f2f2f2f2;
  }
  .selec_left{
    width:1.77rem;
  }
  .selec_title{
    font-size:14px;
    color:#323232;
    font-family: "黑体";
    display:-webkit-flex;
    margin-top:.13rem;
  }
  .selec_left h3{
    margin-left:.12rem;
  }
  .selec_left p{
    margin-left:.12rem;
  }
  .selec_title img{
    width:.5rem;
    height:.15rem;
  }
  .selec_word{
    font-size:11px;
    color:#ababab;
    margin-top:.02rem;
  }
  .imgs{
    width:1.68rem;
    height:.69rem;
    margin-left:.02rem;
    margin-top:.04rem;
  }
  .selec_center{
    width:.88rem;
  }
  .selec_center h3{
    margin-left:.13rem;
  }
  .selec_center p{
    margin-left:.1rem;
  }
  .selec_center img:last-child{
    width:.78rem;
    height:.69rem;
    margin:.08rem auto 0;
  }
  .selec_right h3{
    margin-left:.06rem;
  }
  .selec_right p{
    margin-left:.12rem;
  }
  .selec_right img:last-child{
    width:.71rem;
    height:.72rem;
    margin:.05rem auto 0;
  }
  /* 猜你喜欢 */
  .you_like{
    display:-webkit-flex;
    -webkit-flex-wrap:wrap;
  }
  .you_like a{
    width:50%;
    position: relative;
    box-sizing: border-box;
    border-top:2px solid #f2f2f2f2;
    padding-bottom:.16rem;
  }
  .you_like a:nth-child(1){
    border-top: 0;
  }
  .you_like a:nth-child(2){
    border-top: 0;
  }
  .you_like a:nth-child(2n-1){
    border-right:2px solid #f2f2f2f2;
  }
  .you_like a img:nth-child(1){
    width:1.25rem;
    height:1.38rem;
    margin:.2rem auto .15rem;
  }
  .you_like a p{
    font-size:13px;
    color:#313131;
    width:1.55rem;
    margin-left:.1rem;
    margin-bottom:.2rem;
  }
  .you_like a h4{
    margin-left:.1rem;
  }
  .you_like a img:last-child{
    width:.28rem;
    height:.27rem;
    position: absolute;
    bottom:.12rem;
    right:.1rem;
  }
</style>
