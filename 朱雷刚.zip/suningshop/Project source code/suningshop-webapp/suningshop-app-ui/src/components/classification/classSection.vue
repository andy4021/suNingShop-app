<template>
  <section>
    <!-- 左边导航 -->
    <div class="left">
      <ul id="menu">
        <li>
          <img src="/static/imgClass/left011.png" alt=""/>
          <span>时令水果</span>
        </li>
        <li>
          <span>生鲜水产</span>
        </li>
        <li>
          <span>休闲零食</span>
        </li>
        <li>
          <span>生鲜水产</span>
        </li>
        <li>
          <span>生鲜水产</span>
        </li>
        <li>
          <span>生鲜水产</span>
        </li>
        <li>
          <span>生鲜水产</span>
        </li>
        <li>
          <span>生鲜水产</span>
        </li>
        <li>
          <span>生鲜水产</span>
        </li>
        <li>
          <span>生鲜水产</span>
        </li>
        <li>
          <span>生鲜水产</span>
        </li>
        <li>
          <span>生鲜水产</span>
        </li>
        <li>
          <span>生鲜水产</span>
        </li>
        <li>
          <span>生鲜水产</span>
        </li>
        <li>
          <span>生鲜水产</span>
        </li>
      </ul>
    </div>
    <!-- 右边详情 -->
    <div class="right">
      <img src="/static/imgClass/right01.png" alt=""/>
      <p>国产水果</p>
      <div class="detail">
        <img src="/static/imgClass/right02.png" alt=""/>
        <div class="deta_right">
          <p>智利车厘子单J 250g装</p>
          <span>￥24.9</span>
          <img src="/static/imgClass/right04.png" alt=""/>
        </div>
      </div>
      <div class="detail">
        <img src="/static/imgClass/right03.png" alt=""/>
        <div class="deta_right">
          <p>智利车厘子单J 250g装</p>
          <span>￥24.9</span>
          <img src="/static/imgClass/right04.png" alt=""/>
        </div>
      </div>
      <div class="detail">
        <img src="/static/imgClass/right02.png" alt=""/>
        <div class="deta_right">
          <p>智利车厘子单J 250g装</p>
          <span>￥24.9</span>
          <img src="/static/imgClass/right04.png" alt=""/>
        </div>
      </div>
      <div class="detail">
        <img src="/static/imgClass/right02.png" alt=""/>
        <div class="deta_right">
          <p>智利车厘子单J 250g装</p>
          <span>￥24.9</span>
          <img src="/static/imgClass/right04.png" alt=""/>
        </div>
      </div>
      <div class="detail">
        <img src="/static/imgClass/right02.png" alt=""/>
        <div class="deta_right">
          <p>智利车厘子单J 250g装</p>
          <span>￥24.9</span>
          <img src="/static/imgClass/right04.png" alt=""/>
        </div>
      </div>
      <div class="detail">
        <img src="/static/imgClass/right05.png" alt=""/>
        <div class="deta_right">
          <p>智利车厘子单J 250g装</p>
          <span>￥24.9</span>
        </div>
      </div>
      <img class="end" src="/static/imgClass/right06.png" alt=""/>
    </div>
  </section>


</template>

<script>
    export default {
        name: "classSection"
    }
</script>

<style scoped>
  section{
     /*-webkit-flex:1;*/
     /*overflow-y: auto;*/
      /*overflow-x: hidden;*/
     display:-webkit-flex;
   }
  .left{
    /*-webkit-flex:1;*/
    width:.83rem;
    flex-shrink:0;
    overflow-y: auto;
    overflow-x: hidden;
  }
  .left ul{
    display:-webkit-flex;
    flex-direction:column;
    overflow-y:auto;
    background:#f5f5f5;
  }
  .left ul li{
    display:-webkit-flex;
    width:100%;
    height:.5rem;
    -webkit-justify-content:center;
    -webkit-align-items:center;
    /* background:url(../images/imgClass/left01.png) no-repeat;
    background-size:.03rem .5rem; */
    -webkit-flex-shrink:0;
  }
  .left ul li img{
    width:.13rem;
    height:.13rem;
    margin-right:.03rem;
  }
  .left ul li span{
    font-size: 13px;
    color:black;
  }
  .right{
    -webkit-flex:1;
    padding-left:.1rem;
    overflow-y:auto;
  }
  .right img:nth-child(1){
    width:2.73rem;
    height:.78rem;
    margin-top:.1rem;
  }
  .right p:nth-child(2){
    font-size:11px;
    color:#767676;
    height:.22rem;
    background:#fafafa;
    border-radius:.8rem;
    margin-top:.1rem;
    padding-left:.11rem;
    margin-right:.1rem;
    line-height:.22rem;
  }
  .detail{
    display: -webkit-flex;
    padding-top:.15rem;
    width:100%;
  }
  .deta_right{
    position: relative;
    -webkit-flex:1;
    border-bottom:1px solid #f2f2f2;
    padding-bottom:.15rem;
  }
  .detail img:nth-child(1){
    width:.58rem;
    height:.65rem;
    margin-left:.06rem;
    margin-right:.13rem;
  }
  .deta_right p{
    font-size:.13rem;
    color:#3a3a3a;
  }
  .deta_right span{
    font-size:11px;
    color:#ef752d;
    font-weight:900;
    display:block;
    margin-top:.36rem;
  }
  .deta_right img{
    width:.22rem;
    height:.22rem;
    position: absolute;
    right:.1rem;
    bottom:.15rem;
  }
  .end{
    width:.7rem;
    height:.48rem;
    margin:.1rem auto 0;
  }
</style>
