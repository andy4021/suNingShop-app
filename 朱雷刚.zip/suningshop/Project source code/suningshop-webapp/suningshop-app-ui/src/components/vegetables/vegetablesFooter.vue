<template>
    
</template>

<script>
    export default {
        name: "vegetablesFooter"
    }
</script>

<style scoped>

</style>