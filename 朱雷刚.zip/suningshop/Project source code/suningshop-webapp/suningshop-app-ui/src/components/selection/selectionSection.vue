<template>
    <section>
        <p class="search">
            <img src="/static/selection/sec01.png" alt=""/>
            <span>搜索你想要的商品</span>
        </p>
        <!-- banner -->
        <div class="banner">
            <!-- <img src="img/banner.png" width="100%"/> -->
            <div class="swiper-container">
                <div class="swiper-wrapper">
                    <div class="swiper-slide"><img src="/static/img-id/adv1.png" alt=""/></div>
                    <div class="swiper-slide">Slide 2</div>
                    <div class="swiper-slide">Slide 3</div>
                </div>
                <!-- 如果需要分页器 -->
                <div class="swiper-pagination"></div>

                <!-- 如果需要导航按钮 -->
                <!-- <div class="swiper-button-prev"></div> -->
                <!-- <div class="swiper-button-next"></div> -->

                <!-- 如果需要滚动条 -->
                <!-- <div class="swiper-scrollbar"></div> -->
            </div>
        </div>
        <div class="menu">
            <a href="#"><img src="/static/selection/nav01.png" alt=""/><span>生鲜果蔬</span></a>
            <a href="#"><img src="/static/selection/nav02.png" alt=""/><span>酒水饮料</span></a>
            <a href="#"><img src="/static/selection/nav03.png" alt=""/><span>苏宁精选</span></a>
            <a href="#"><img src="/static/selection/nav04.png" alt=""/><span>烘焙乳品</span></a>
            <a href="#"><img src="/static/selection/nav05.png" alt=""/><span>生活用品</span></a>
        </div>
        <img class="adv01" src="/static/selection/adv01.png" alt=""/>
        <div class="spell">
            <div class="spell_top">
                <div class="spell_left">
                    <h3>苏宁拼购</h3>
                    <span>两人拼更实惠 全场包邮</span>
                </div>
                <p class="spell_right">查看更多</p>
            </div>
            <div class="spell_goodslist">
                <div class="spell_goods">
                    <img class="spell_imgs" src="/static/selection/goods01.png" alt=""/>
                    <div class="spell_price">
                        <img src="/static/selection/goods03.png" alt=""/>
                        <p><span><i>￥</i>30.9</span><span><i>￥</i>41.8</span></p>
                    </div>
                </div>
                <div class="spell_goods">
                    <img class="spell_imgs" src="/static/selection/goods02.png" alt=""/>
                    <div class="spell_price">
                        <img src="/static/selection/goods03.png" alt=""/>
                        <p><span><i>￥</i>30.9</span><span><i>￥</i>41.8</span></p>
                    </div>
                </div>
                <div class="spell_goods">
                    <img class="spell_imgs" src="/static/selection/goods01.png" alt=""/>
                    <div class="spell_price">
                        <img src="/static/selection/goods03.png" alt=""/>
                        <p><span><i>￥</i>30.9</span><span><i>￥</i>41.8</span></p>
                    </div>
                </div>
                <div class="spell_goods">
                    <img class="spell_imgs" src="/static/selection/goods01.png" alt=""/>
                    <div class="spell_price">
                        <img src="/static/selection/goods03.png" alt=""/>
                        <p><span><i>￥</i>30.9</span><span><i>￥</i>41.8</span></p>
                    </div>
                </div>
            </div>
            <div class="spell_detail">
                <div class="spellleft">
                    <div class="spell_detaltop">
                        <h3>掌上抢</h3>
                        <div class="spell_time">
                            <p>16点场 距离下场</p><span>00</span>:<span>00</span>:<span>00</span>
                        </div>
                    </div>
                    <div class="spell_detalgood">
                        <a href=""><img src="/static/selection/goods05.png" alt=""/><span><i>￥</i>19.9</span></a>
                        <a href="">
                            <img src="/static/selection/goods04.png" alt=""/>
                            <p class="price"><span><i>￥</i>8999</span><span><i>￥</i>9999</span></p>
                        </a>
                    </div>
                </div>
                <div class="spellleft">
                    <div class="spell_detaltop">
                        <h3>苏宁奥莱</h3>
                        <div class="spell_time">
                            <p>阿玛尼满599减200</p>
                        </div>
                    </div>
                    <div class="spell_detalgood spell_right">
                        <a href=""><img src="/static/selection/goods05.png" alt=""/><span>阿玛尼男</span></a>
                        <a href="">
                            <img src="/static/selection/goods04.png" alt=""/>
                            <span>阿玛尼男</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="home">
            <div class="spell_left spelltop">
                <img src="/static/selection/goods06.png" alt=""/>
                <h3>精致家</h3>
            </div>
            <img class="adv02" src="/static/selection/adv02.png" alt=""/>
            <div class="home_goodslist">
                <div class="home_goods">
                    <h3>苏宁家电</h3>
                    <p>16点场 距离下场</p>
                    <img src="/static/selection/goods07.png" alt=""/>
                </div>
                <div class="home_goods">
                    <h3>生活家电</h3>
                    <p>16点场 距离下场</p>
                    <img src="/static/selection/goods08.png" alt=""/>
                </div>
                <div class="home_goods">
                    <h3>家具建材</h3>
                    <p>16点场 距离下场</p>
                    <img src="/static/selection/goods08.png" alt=""/>
                </div>
                <div class="home_goods">
                    <h3>智能生活</h3>
                    <p>16点场 距离下场</p>
                    <img src="/static/selection/goods08.png" alt=""/>
                </div>
            </div>
        </div>
        <div class="life home">
            <div class="spell_left spelltop">
                <img src="/static/selection/goods09.png" alt=""/>
                <h3>享生活</h3>
            </div>
            <img class="adv02" src="/static/selection/goods10.png" alt=""/>
            <div class="home_goodslist">
                <div class="home_goods">
                    <h3>生活家具</h3>
                    <p>16点场 距离下场</p>
                    <img src="/static/selection/goods11.png" alt=""/>
                </div>
                <div class="home_goods">
                    <h3>家有萌宝</h3>
                    <p>16点场 距离下场</p>
                    <img src="/static/selection/goods12.png" alt=""/>
                </div>
                <div class="home_goods">
                    <h3>手机数码</h3>
                    <p>16点场 距离下场</p>
                    <img src="/static/selection/goods08.png" alt=""/>
                </div>
                <div class="home_goods">
                    <h3>时尚服饰</h3>
                    <p>16点场 距离下场</p>
                    <img src="/static/selection/goods08.png" alt=""/>
                </div>
            </div>
        </div>
    </section>
</template>

<script>
    export default {
        name: "selectionSection"
    }
</script>

<style scoped>
    @import "../../assets/css/swiper.min.css";
    section{
        width:100%;
        -webkit-flex:1;
        overflow-y: auto;
        overflow-x: hidden;
        position: relative;
        background:#f2f2f2;
    }
    .search{
        width:3.51rem;
        height:.3rem;
        border-radius:.13rem;
        position:absolute;
        left:.12rem;
        top:.07rem;
        z-index:2;
        display:-webkit-flex;
        background:#f2f2f2;
        -webkit-align-items:center;
    }
    .search img{
        width:.16rem;
        height:.16rem;
        margin:0 .12rem;
    }
    .search span{
        font-size:12px;
        color:#9c9c9c;
    }
    .menu{
        width:100%;
        display: -webkit-flex;
        -webkit-flex-wrap:wrap;
        background:white;
        border-top-left-radius:.11rem;
        border-top-right-radius:.11rem;
        position:absolute;
        left:0;
        top:1.4rem;
        z-index:2;
        padding-bottom:.18rem;
    }
    .menu a{
        width:20%;
        text-align: center;
    }
    .menu img{
        width: .41rem;
        height: .41rem;
        margin:.14rem auto .07rem;
    }
    .menu span{
        color: #333333;
        font-size: 11px;
        display: block;
    }
    /* banner */
    .swiper-container{
        width:100%;
        /* height:1.5rem; */
    }
    .swiper-slide img{
        width:100%;
        /* height:1.4rem; */
    }
    .swiper-pagination-bullet{
        width:4px;
        height:4px;
    }
    .swiper-pagination-bullet-active{
        width:.1rem;
        height:4px;
        background:white;
        opacity:1;
    }
    .adv01{
        width:3.51rem;
        height:.98rem;
        margin:.97rem auto 0;

    }
    .spell{
        background:white;
    }
    .spell_top{
        display:-webkit-flex;
        -webkit-justify-content:space-between;
        -webkit-align-items:center;
        padding:0 .17rem 0 .1rem;
        height:.41rem;
    }
    .spell_left{
        display:-webkit-flex;
        -webkit-align-items:baseline;
    }
    .spell_left h3{
        font-size:20px;
        color:#343434;
    }
    .spell_left span{
        font-size:10px;
        color:#4a4a4a;
        margin-left:.13rem;
    }
    .spell_right{
        font-size:12px;
        color:#999999;
    }
    .spell_goodslist{
        display:-webkit-flex;
    }
    .spell_goods{
        width:25%;
        padding-bottom:.1rem;
    }
    .spell_imgs{
        width:.62rem;
        height:.7rem;
        margin:.08rem auto;
    }
    .spell_price{
        display:-webkit-flex;
    }
    .spell_price img{
        width:.36rem;
        height:.15rem;
        margin-left:.1rem;
        margin-right:.03rem;
    }
    .spell_price p span:nth-child(1){
        font-size:15px;
        color:#eb5428;
        display:block;
        margin-bottom:.06rem;
    }
    .spell_price p span:last-child{
        font-size:12px;
        color:#9b9b9b;
        display:block;
        text-decoration:line-through;
    }
    .spell_price p span i{
        font-size:.06rem;
        font-style:normal;
    }
    .spell_detail{
        width:100%;
        display:-webkit-flex;
    }
    .spellleft{
        width:50%;
        border-right:2px solid #f2f2f2;
        box-sizing:border-box;
    }
    .spell_detaltop h3{
        font-size:15px;
        color:#444444;
        margin:.08rem 0 .05rem;
        margin-left:.08rem;
    }
    .spell_time{
        font-size:10px;
        display:-webkit-flex;
        margin-left:.08rem;
    }
    .spell_time p{
        font-size:10px;
        color:#9a9a9a;
    }
    .spell_detalgood{
        display:-webkit-flex;
        margin-top:.04rem;
        padding-bottom:.08rem;
    }
    .spell_detalgood a{
        width:50%;
    }
    .spell_detalgood a img{
        width:.65rem;
        height:.65rem;
        margin:0 auto;
    }
    .spell_detalgood a span{
        font-size:10px;
        color:#eb5428;
        display:block;
        margin-left:.08rem;
    }
    .spell_detalgood a span i{
        font-size:10px;
        font-style:normal;
        transform:scale(0.6);
    }
    .spell_detalgood .price{
        display:-webkit-flex;
    }
    .spell_detalgood .price span:last-child{
        font-size:8px;
        color:#999999;
        text-decoration:line-through;
        margin-left:0;
        transform:scale(0.8);
        align-self:baseline;
    }
    .spellleft .spell_right a span{
        color:#999999;
        text-align: center;
    }
    .home{
        background:white;
        margin-top:.09rem;
    }
    .spelltop{
        line-height:.4rem;
    }
    .spelltop img{
        width:.18rem;
        height:.16rem;
        margin-left:.12rem;
        margin-right:.05rem;
    }
    .adv02{
        width:100%;
        height:1.1rem;
    }
    .home_goodslist{
        display:-webkit-flex;
        -webkit-flex-wrap:wrap;
    }
    .home_goods{
        width:50%;
        border-right:2px solid #f2f2f2;
        border-bottom:2px solid #f2f2f2;
        box-sizing:border-box;
    }
    .home_goods:nth-child(2n){
        border-right:0;
    }
    .home_goods h3{
        font-size:15px;
        color:#333333;
        margin-left:.12rem;
        margin-top:.1rem;
    }
    .home_goods p{
        font-size:10px;
        color:#999999;
        margin-left:.12rem;
    }
    .home_goods img{
        width:1.55rem;
        height:.65rem;
        margin:0 auto;
    }
</style>