<template>
    <div class="flex_sec">
      <class-header></class-header>
      <class-section></class-section>
      <class-footer></class-footer>
    </div>
</template>

<script>
    import classHeader from "../components/classification/classHeader"
    import classSection from "../components/classification/classSection"
    import classFooter from "../components/classification/classFooter"
    export default {
        name: "classification",
        components:{
          "class-header":classHeader,
          "class-section":classSection,
          "class-footer":classFooter
        }
    }
</script>

<style>
  @import "../assets/css/public.css";
</style>
